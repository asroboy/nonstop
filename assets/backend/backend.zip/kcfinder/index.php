<?php
if(@$_SESSION['file_manager_slur'] != TRUE){
	require "browse.php";
} else {
	
}
?>
